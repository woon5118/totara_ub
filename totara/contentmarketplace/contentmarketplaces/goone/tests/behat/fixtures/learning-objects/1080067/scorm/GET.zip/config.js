"use strict";

const ScormPackage_Value = {
    "token": "3shp6k113u8iqq18vj68nerci16k",
    "version": "1.2",
    "id": 1080067
};
